#ifndef _CLOTHES_H_

#define _CLOTHES_H_

#include <iostream>
#include <string>

using namespace std;

class Clothes {
public:
  string color;
  string size;

  Clothes(string color, string size) {
    this->color = color;
    this->size = size;
  }

  string getColor() {
    return color;
  }

  void setColor(string color) {
    this->color = color;
  }

  string getSize() {
    return size;
  }

  void setSize(string size) {
    this->size = size;
  }

  virtual void print() = 0;
};

class Sweater : public Clothes {
public:
  Sweater(string color, string size) : Clothes(color, size) {}

  void print() {
    cout << "Color: " << color << endl;
    cout << "Size: " << size << endl;
  }
};

class Pants : public Clothes {
public:
  Pants(string color, string size) : Clothes(color, size) {}

  void print() {
    cout << "Color: " << color << endl;
    cout << "Size: " << size << endl;
  }
};

class Shoe : public Clothes {
public:
  int shoe_size;

  Shoe(string color, int shoe_size) : Clothes(color, "No size") {
    this->shoe_size = shoe_size;
  }

  int getShoeSize() {
    return shoe_size;
  }

  void setShoeSize(int shoe_size) {
    this->shoe_size = shoe_size;
  }

  void print() {
    cout << "Color: " << color << endl;
    cout << "Shoe Size: " << shoe_size << endl;
  }
};

#endif // _CLOTHES_H_