**#ifndef TECHNICAL_DEVICES_H
#define TECHNICAL_DEVICES_H

#include <iostream>
#include <string>

using namespace std;

class TechnicalDevices {
public:
string model;
string color;

TechnicalDevices(string model, string color) {
this->model = model;
this->color = color;
}

string getModel() {
return model;
}

void setModel(string model) {
this->model = model;
}

string getColor() {
return color;
}

void setColor(string color) {
this->color = color;
}

virtual void print() = 0;
};

class Phone : public TechnicalDevices {
public:
string operating_system;

Phone(string model, string color, string operating_system) : TechnicalDevices(model, color) {
this->operating_system = operating_system;
}

string getOperatingSystem() {
return operating_system;
}

void setOperatingSystem(string operating_system) {
this->operating_system = operating_system;
}

void print() {
cout << "Model: " << model << endl;
cout << "Color: " << color << endl;
cout << "Operating System: " << operating_system << endl;
}
};

class Computer : public TechnicalDevices {
public:
string model;
string function;
string operating_system;

Computer(string model, string color, string function, string operating_system) : TechnicalDevices(model, color) {
this->model = model;
this->function = function;
this->operating_system = operating_system;
}

string getModel() {
return model;
}

void setModel(string model) {
this->model = model;
}

string getFunction() {
return function;
}

void setFunction(string function) {
this->function = function;
}

string getOperatingSystem() {
return operating_system;
}

void setOperatingSystem(string operating_system) {
this->operating_system = operating_system;
}

void print() {
cout << "Model: " << model << endl;
cout << "Color: " << color << endl;
cout << "Function: " << function << endl;
cout << "Operating System: " << operating_system << endl;
}
};

class SmartWatch : public TechnicalDevices {
public:
string model;
string color;

SmartWatch(string model, string color) : TechnicalDevices(model, color) {}

string getModel() {
return model;
}

void setModel(string model) {
this->model = model;
}

string getColor() {
return color;
}

void setColor(string color) {
this->color = color;
}

void print() {
cout << "Model: " << model << endl;
cout << "Color: " << color << endl;
}
};

#endif TECHNICAL_DEVICES_H