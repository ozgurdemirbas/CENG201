
#ifndef VEHICLES_H

#define VEHICLES_H

#include <iostream>
#include <string>

using namespace std;

class Vehicles {
public:
string color;

Vehicles(string color) {
this->color = color;
}

string getColor() {
return color;
}

void setColor(string color) {
this->color = color;
}

virtual void print() = 0;
};

class Scooter : public Vehicles {
public:
string category;
bool electric;

Scooter(string color, string category, bool electric) : Vehicles(color) {
this->category = category;
this->electric = electric;
}

string getCategory() {
return category;
}

void setCategory(string category) {
this->category = category;
}

bool getElectric() {
return electric;
}

void setElectric(bool electric) {
this->electric = electric;
}

void print() {
cout << "Color: " << color << endl;
cout << "Category: " << category << endl;
cout << "Electric: " << electric << endl;
}
};

class Skateboard : public Vehicles {
public:
string color;
int size;

Skateboard(string color, int size) : Vehicles(color) {
this->size = size;
}

int getSize() {
return size;
}

void setSize(int size) {
this->size = size;
}

void print() {
cout << "Color: " << color << endl;
cout << "Size: " << size << endl;
}
};

class Bicycle : public Vehicles {
public:
string model;
string color;
int wheel_size;

Bicycle(string model, string color, int wheel_size) : Vehicles(color) {
this->model = model;
this->wheel_size = wheel_size;
}

string getModel() {
return model;
}

void setModel(string model) {
this->model = model;
}

int getWheelSize() {
return wheel_size;
}

void setWheelSize(int wheel_size) {
this->wheel_size = wheel_size;
}

void print() {
cout << "Color: " << color << endl;
cout << "Model: " << model << endl;
cout << "Wheel Size: " << wheel_size << endl;
}
};

#endif VEHICLES_H