#include <iostream>
#include <string>

#include "Clothes.h"
#include "Vehicles.h"
#include "TechnicalDevices.h"
#include "User.h"

using namespace std;

// Function to generate a random prize based on item category
int generateRandomPrize(string category) {
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dist;

    if (category == "clothes") {
        dist = uniform_int_distribution<>(10, 100);
    } else if (category == "tech") {
        dist = uniform_int_distribution<>(200, 1000);
    } else if (category == "vehicle") {
        dist = uniform_int_distribution<>(50, 500);
    } else {
        return 0; // Handle invalid category
    }

    return dist(gen);
}

void displayItems(const vector<Item*>& items) {
    cout << "Items:" << endl;
    for (const Item* item : items) {
        cout << "- " << item->getName() << " (" << item->getCategory() << "), Prize: $" << item->getPrize() << endl;
    }
}

void addItemToStorage() {
    string name, category;
    // ... (collect other item details based on category)

    int prize = generateRandomPrize(category);

    Item* item = nullptr;
    if (category == "clothes") {
        item = new Clothes(name, category, /* other details */, prize);
    } else if (category == "vehicle") {
        item = new Vehicle(name, category, /* other details */, prize);
    } // ... (similarly for other categories)

    storage.push_back(item);
    cout << "Item added to storage." << endl;
}

void removeItemFromStorage() {
    int index;
    displayItems(storage);
    cout << "Enter the index of the item to remove: ";
    cin >> index;

    if (index >= 0 && index < storage.size()) {
        delete storage[index]; // Delete dynamically allocated item
        storage.erase(storage.begin() + index);
        cout << "Item removed." << endl;
    } else {
        cout << "Invalid index." << endl;
    }
}

void addItemToSellingInc() {
    int index;
    displayItems(storage);
    cout << "Enter the index of the item to move to Selling Inc.: ";
    cin >> index;

    if (index >= 0 && index < storage.size()) {
        Item* item = storage[index];
        storage.erase(storage.begin() + index);
        sellingItems.push_back(item);
        cout << "Item moved to Selling Inc." << endl;
    } else {
        cout << "Invalid index." << endl;
    }
}

void sellItem() {
    int index;
    displayItems(sellingItems);
    cout << "Enter the index of the item to sell: ";
    cin >> index;

    if (index >= 0 && index < sellingItems.size()) {
        // ... (handle item sale, e.g., update user balance, remove item from list)
        delete sellingItems[index]; // Delete dynamically allocated item
        sellingItems.erase(sellingItems.begin() + index);
        cout << "Item sold." << endl;
    } else {
        cout << "Invalid index." << endl;
    }
}

vector<string> itemCategories = {"clothes", "vehicles", "technicaldevices"};
vector<string> buyerDescriptions = {"a man", "a woman", "a student", "a businessperson", "an athlete"};

void generateRandomBuyerRequest() {
    string category = itemCategories[rand() % itemCategories.size()];
    string description = buyerDescriptions[rand() % buyerDescriptions.size()];

    string itemDetails;
    // ... (construct item details based on category, e.g., "blue android laptop")

    cout << description << " wants a " << itemDetails << ". Would you like to sell it?" << endl;
    cout << "1. Yes" << endl;
    cout << "2. No" << endl;

    int choice;
    cin >> choice;

    if (choice == 1) {
        // Handle item sale (e.g., remove from storage or Selling Inc.)
        cout << "Item sold!" << endl;
    } else {
        cout << "Request declined." << endl;
    }
}


int main() {
  // User login
  User user;
  string username;
  string password;

  cout << "Username: ";
  cin >> username;

  cout << "Password: ";
  cin >> password;

  user.login(username, password);

  if (!user.getLogin()) {
    // User is not registered
    cout << "You need to register." << endl;

    // User registration
    cout << "Username: ";
    cin >> username;

    cout << "Password: ";
    cin >> password;

    cout << "Name: ";
    cin >> user.name;

    cout << "Surname: ";
    cin >> user.surname;

    user.register(username, password, user.name, user.surname);

    // User login
    user.login(username, password);
  }
    int selection;
    cout << "Choose a section:" << endl;
    cout << "1. Selling Inc." << endl;
    cout << "2. Storage" << endl;
    cout << "Selection: ";
    cin >> selection;

    switch (selection) {
        case 1:
            // Code for selling section
            // ...
            break;
        case 2:
            // Code for storage section
            // ...
            break;
        default:
            cout << "Invalid selection" << endl;
            return 0;
    }
  // Main class selection
  int selection;
  cout << "1. Clothes" << endl;
  cout << "2. Technical devices" << endl;
  cout << "3. Vehicles" << endl;
  cout << "Selection: ";
  cin >> selection;

  // Subclass selection
  int subselection;
  switch (selection) {
    case 1:
      // Clothes subclasses
      cout << "1. Sweater" << endl;
      cout << "2. Pants" << endl;
      cout << "3. Shoes" << endl;
      cout << "Selection: ";
      cin >> subselection;
      break;
    case 2:
      // Technical device subclasses
      cout << "1. Phone" << endl;
      cout << "2. Computer" << endl;
      cout << "3. Smart watch" << endl;
      cout << "Selection: ";
      cin >> subselection;
      break;
    case 3:
      // Vehicle subclasses
      cout << "1. Scooter" << endl;
      cout << "2. Skateboard" << endl;
      cout << "3. Bicycle" << endl;
      cout << "Selection: ";
      cin >> subselection;
      break;
    default:
      cout << "Invalid selection" << endl;
      return 0;
  }

  // Product selection
  switch (selection) {
    case 1:
      switch (subselection) {
        case 1:
          // Sweater
          break;
        case 2:
          // Pants
          break;
        case 3:
          // Shoes
          {
            // Shoe properties
            string color;
            int size;

            // Get information from the user
            cout << "Color: ";
            cin >> color;

            cout << "Size: ";
            cin >> size;

            // Create a shoe object
            Shoes shoe1(color, size);

            // Print the shoe
            shoe1.print();
          }
          break;
      }
      break;
    case 2:
      switch (subselection) {
        case 1:
          // Phone
          break;
        case 2:
          // Computer
          break;
        case 3:
          // Smart watch
          break;
      }
      break;
    case 3:
      switch (subselection) {
        case 1:
          // Scooter
          break;
        case 2:
          // Skateboard
          break;
        case 3:
          // Bicycle
          break;
      }
      break;
  }

  return 0;
}